<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        {{env('site_name')}}
    </div>
    <!-- Default to the left -->
</footer>
