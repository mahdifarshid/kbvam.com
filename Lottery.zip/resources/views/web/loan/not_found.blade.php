<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<div class="container" style="margin: 0 auto;width: 500px">

    <img src="{{asset('images/not_found.png')}}" style="width: 500px" alt="">
    <br>
    <br>
    <h2 style="display: block;text-align: center;margin: 0 auto;">متاسفانه مشخصات وام مورد نظر پیدا نشد</h2>
    <br>
    <br>
    <br>
    <a href="{{url('/followup')}}" style="display: block;color: green;text-align: center;margin: 0 auto">برای برگشت به صفحه قبلی کلیک کنید</a>
</div>

</body>
</html>
