<style>


    .kbvam_header_image {
        content: url("images/kbpsd.jpg");
        height: 500px; background-position: center center; background-repeat: no-repeat;object-fit: cover;;  overflow: hidden;
    }
    @media (max-width: 800px) {
        .kbvam_header_image {
            height: 780px;
            object-fit:unset;
            background-position: unset;
            content: url("images/kbvam_mobile_version2.jpg");
        }
        .card_bottom_of_header{
            margin-top: 266px !important;
        }
    }

</style>


<img src="" alt="" class="kbvam_header_image" style="width: 100%;">
